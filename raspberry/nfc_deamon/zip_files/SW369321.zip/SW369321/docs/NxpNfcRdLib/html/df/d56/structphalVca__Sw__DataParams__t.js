var structphalVca__Sw__DataParams__t =
[
    [ "wId", "d3/d83/group__phalVca.html#gaa0d6558483263bfc30964670290da61d", null ],
    [ "pPalMifareDataParams", "d3/d83/group__phalVca.html#ga0e3d2e2ac96ab198c9b4ee91cdac5070", null ],
    [ "pKeyStoreDataParams", "d3/d83/group__phalVca.html#gad5b4d4b082953e68bf23d407f20d3102", null ],
    [ "pCryptoDataParams", "d3/d83/group__phalVca.html#ga763cad67213cde29e0c929dba74772bc", null ],
    [ "pCryptoRngDataParams", "d3/d83/group__phalVca.html#ga89568d21e4e117533b9874b6ba1db85d", null ],
    [ "pCardTable", "d3/d83/group__phalVca.html#gaaa2f41ca8e1512495ec5a2c3cc084303", null ],
    [ "pIidTable", "d3/d83/group__phalVca.html#gacdb19cd829102c52bf98d02ca49e2e55", null ],
    [ "wCurrentCardTablePos", "d3/d83/group__phalVca.html#ga07cf77633b3fa2176694343c8a54373b", null ],
    [ "wNumCardTableEntries", "d3/d83/group__phalVca.html#ga1d0145c775ccc682988230704ac38217", null ],
    [ "wNumIidTableEntries", "d3/d83/group__phalVca.html#ga5e389f853d358b7a2ff245fb1ca71d89", null ],
    [ "wCurrentIidIndex", "d3/d83/group__phalVca.html#gaebecabe16d3b95efa56c0da52b776bb8", null ],
    [ "wCurrentIidTablePos", "d3/d83/group__phalVca.html#gafb54dc5ebd4733e262be2a63f41969cc", null ],
    [ "wAdditionalInfo", "d3/d83/group__phalVca.html#ga67e9113c9d0fca83255ea15526119324", null ],
    [ "bSessionAuthMACKey", "d3/d83/group__phalVca.html#gaf80c51c2ec7b627a8d7b5b389a1708ff", null ],
    [ "eVCState", "d3/d83/group__phalVca.html#ga2d91c2b33845c41e8b6e5aec2887ba77", null ],
    [ "ePCState", "d3/d83/group__phalVca.html#gae4bb8898a4fd0b767c65d08cb5f1b7b9", null ],
    [ "pAlDataParams", "d3/d83/group__phalVca.html#ga487770466acb618bb75efb835880210c", null ],
    [ "bWrappedMode", "d3/d83/group__phalVca.html#ga926afe433187903a59cadef7ed625fb1", null ],
    [ "bExtendedLenApdu", "d3/d83/group__phalVca.html#gae6d537197aeffdcc0f307f272d2c05e5", null ],
    [ "bOption", "d3/d83/group__phalVca.html#ga721bcbd8fda5fcbfb4ca3d2492c6db45", null ],
    [ "bLowerBoundThreshold", "d3/d83/group__phalVca.html#gaac24673dafb92ae329739919b64b9a08", null ]
];