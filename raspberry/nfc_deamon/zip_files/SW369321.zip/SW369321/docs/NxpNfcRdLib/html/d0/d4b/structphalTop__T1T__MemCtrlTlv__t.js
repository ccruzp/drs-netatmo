var structphalTop__T1T__MemCtrlTlv__t =
[
    [ "wOffset", "d2/d7b/group__phalTop__Sw.html#gab2bf5a4f01d3297622c4effd378d8fa9", null ],
    [ "wByteAddr", "d2/d7b/group__phalTop__Sw.html#ga17d22cf6e49a4abb8ccc2bdb9add5351", null ],
    [ "bSizeInBytes", "d2/d7b/group__phalTop__Sw.html#ga07152ca7858dabb6bda66d6ca2bedca7", null ],
    [ "bBytesPerPage", "d2/d7b/group__phalTop__Sw.html#gaab7d7d5943c6bd27edc7ba7afaf8d53f", null ]
];