var group__phalMfdfLight__DataManagement =
[
    [ "phalMfdfLight_ReadData", "db/df4/group__phalMfdfLight__DataManagement.html#ga2e2264a5be4c9e168b37e01608ac95dc", null ],
    [ "phalMfdfLight_WriteData", "db/df4/group__phalMfdfLight__DataManagement.html#ga806c0b8f22efb3d96ee3e0efd0e3ee6c", null ],
    [ "phalMfdfLight_GetValue", "db/df4/group__phalMfdfLight__DataManagement.html#gaea529f899c795eb0c837291b127eab14", null ],
    [ "phalMfdfLight_Credit", "db/df4/group__phalMfdfLight__DataManagement.html#gac782326dd66c4bc07bffa2f337a3b973", null ],
    [ "phalMfdfLight_Debit", "db/df4/group__phalMfdfLight__DataManagement.html#gaa90df276d336a879e275de0d5322e635", null ],
    [ "phalMfdfLight_LimitedCredit", "db/df4/group__phalMfdfLight__DataManagement.html#gaf196f334d33278e0e031eeb8c30a8147", null ],
    [ "phalMfdfLight_ReadRecords", "db/df4/group__phalMfdfLight__DataManagement.html#ga76aea811c9ca9279f7cfea1812087912", null ],
    [ "phalMfdfLight_WriteRecord", "db/df4/group__phalMfdfLight__DataManagement.html#gada6504573a553f685db06ccb184b8227", null ],
    [ "phalMfdfLight_UpdateRecord", "db/df4/group__phalMfdfLight__DataManagement.html#gae81707800d9ddbfd43076ac85b4b1f96", null ],
    [ "phalMfdfLight_ClearRecordFile", "db/df4/group__phalMfdfLight__DataManagement.html#gaecb1dd5e5cbb602a4bf5fc3381474e23", null ]
];