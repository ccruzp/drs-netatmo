var group__phalICode__Optional =
[
    [ "phalICode_ReadSingleBlock", "d7/d55/group__phalICode__Optional.html#gacdf7c04c7d91526b2030b1956361e87a", null ],
    [ "phalICode_WriteSingleBlock", "d7/d55/group__phalICode__Optional.html#ga3b0cee00f2d1bbbf055bbf229f39d37f", null ],
    [ "phalICode_LockBlock", "d7/d55/group__phalICode__Optional.html#ga3513a7b96d69b8f72c4d879206a2e87c", null ],
    [ "phalICode_ReadMultipleBlocks", "d7/d55/group__phalICode__Optional.html#ga27c62d2c1f82214c175d6561809dd319", null ],
    [ "phalICode_WriteAFI", "d7/d55/group__phalICode__Optional.html#gaf31d856bace0a52ab6691f2f18be456f", null ],
    [ "phalICode_LockAFI", "d7/d55/group__phalICode__Optional.html#gac81c2745a72d591ca069eaa064769c2c", null ],
    [ "phalICode_WriteDSFID", "d7/d55/group__phalICode__Optional.html#gace8a91fd00f3664cd412524d312fb582", null ],
    [ "phalICode_LockDSFID", "d7/d55/group__phalICode__Optional.html#ga166c50e4b96f6c0c125cde98462e4f36", null ],
    [ "phalICode_GetSystemInformation", "d7/d55/group__phalICode__Optional.html#ga3ee2760629642b2c3f90e4fb6bfdb342", null ],
    [ "phalICode_GetMultipleBlockSecurityStatus", "d7/d55/group__phalICode__Optional.html#gacd8b7518bbec5a101f802abcbd668c9e", null ],
    [ "phalICode_FastReadMultipleBlocks", "d7/d55/group__phalICode__Optional.html#gaaf262cbf30b3536c04cdf4f8db07c0a0", null ],
    [ "phalICode_ExtendedReadSingleBlock", "d7/d55/group__phalICode__Optional.html#ga208b39d966927bc981ccec0cdeb07d93", null ],
    [ "phalICode_ExtendedWriteSingleBlock", "d7/d55/group__phalICode__Optional.html#ga30d4a3dc414d9290881f125841bd78e8", null ],
    [ "phalICode_ExtendedLockBlock", "d7/d55/group__phalICode__Optional.html#ga28d3b9c6e5fde82b972ec575a1f1a86c", null ],
    [ "phalICode_ExtendedReadMultipleBlocks", "d7/d55/group__phalICode__Optional.html#ga474c5332c94c79e95ce25ea6abe90453", null ],
    [ "phalICode_ExtendedGetSystemInformation", "d7/d55/group__phalICode__Optional.html#ga0899d4c1dc411eac91aac76e46cde060", null ],
    [ "phalICode_ExtendedGetMultipleBlockSecurityStatus", "d7/d55/group__phalICode__Optional.html#ga523fa816d262a07f6f8a031bd26a3bdb", null ],
    [ "phalICode_ExtendedFastReadMultipleBlocks", "d7/d55/group__phalICode__Optional.html#gac4f492de9f6cb48fb76a6890d6fd332d", null ]
];