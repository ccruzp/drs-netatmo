var group__phalT1T =
[
    [ "Component : Software", "d7/d20/group__phalT1T__Sw.html", "d7/d20/group__phalT1T__Sw" ],
    [ "phalT1T_ReadUID", "df/d72/group__phalT1T.html#ga12049bf542f48c9d1fdb689629ec10a2", null ],
    [ "phalT1T_ReadAll", "df/d72/group__phalT1T.html#gadf8abecfe4bfb467c178a182c96fcdb1", null ],
    [ "phalT1T_ReadByte", "df/d72/group__phalT1T.html#gaae0872030a8527b470c93b0149c5b501", null ],
    [ "phalT1T_WriteEraseByte", "df/d72/group__phalT1T.html#ga0c2c6e81a1dd7ead6ccd934681f5dc9a", null ],
    [ "phalT1T_WriteNoEraseByte", "df/d72/group__phalT1T.html#ga4068a3a8204de5a6037c38954e9383dd", null ],
    [ "phalT1T_ReadSegment", "df/d72/group__phalT1T.html#ga5a3473a285adaa75dca10fca5638c7c1", null ],
    [ "phalT1T_ReadBlock", "df/d72/group__phalT1T.html#ga4a301cf440f0321d7db39250871937f2", null ],
    [ "phalT1T_WriteEraseBlock", "df/d72/group__phalT1T.html#ga0bad1bc3c3190b279cfad86e5af86e4f", null ],
    [ "phalT1T_WriteNoEraseBlock", "df/d72/group__phalT1T.html#gab3c05c58e68ee9e65bb9e1c23f68aa76", null ]
];