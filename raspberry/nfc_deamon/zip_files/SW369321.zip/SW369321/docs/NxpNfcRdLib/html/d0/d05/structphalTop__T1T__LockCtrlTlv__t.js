var structphalTop__T1T__LockCtrlTlv__t =
[
    [ "wOffset", "d2/d7b/group__phalTop__Sw.html#ga089bcdf110e83f03e237725784cb8a11", null ],
    [ "wByteAddr", "d2/d7b/group__phalTop__Sw.html#ga76aeb5b8e9508bd0d1bc349ea753d70a", null ],
    [ "bSizeInBits", "d2/d7b/group__phalTop__Sw.html#ga0793fd80d874a1274a63334cf51b534a", null ],
    [ "bBytesPerPage", "d2/d7b/group__phalTop__Sw.html#ga31e9e503fbb8b90e7dda4096aaf43c8c", null ],
    [ "bBytesLockedPerBit", "d2/d7b/group__phalTop__Sw.html#ga2b84e12c70d2417b330a1f9ce7f256f3", null ]
];