var group__phalMfNtag42xDna__Cust__Err__Codes =
[
    [ "PHAL_MFNTAG42XDNA_ERR_FORMAT", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#ga8eae9a08d3d5867f45c81d34c599c66c", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_OUT_OF_EEPROM_ERROR", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#ga15f44b9fc42d018cb78ddd6516e095e2", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_NO_SUCH_KEY", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#ga271ab39a8032b227b420de355b0035ad", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_PERMISSION_DENIED", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#ga33c81b8e7f046bb31312a1b68cb2f9e7", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_APPLICATION_NOT_FOUND", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#gaecfa5e8ebf7f20762d625c1b1ed75068", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_BOUNDARY_ERROR", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#gadd7dc8c559b434d0d3140d2d137e2f49", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_COMMAND_ABORTED", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#gac833353e4d0053a6352164a2bb0e974f", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_COUNT", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#ga3fb18113d344bafe6b2671b2028b40a8", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_DUPLICATE", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#gac2221dcd295bfca0aa1491dd3412aeda", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_FILE_NOT_FOUND", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#ga874f61e325ac12f53cf29f1cb9e639a1", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_PICC_CRYPTO", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#ga70f29c52f6f3f618eaa8aa63ba40fa47", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_PARAMETER_ERROR", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#ga29e219468cfa657a67804fd9fc5e71c6", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_DF_GEN_ERROR", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#gaab99aeffa7c159c13cdf252228ae1a92", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_DF_7816_GEN_ERROR", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#ga5d637cbde740ddc49818b76af4b59635", null ],
    [ "PHAL_MFNTAG42XDNA_ERR_CMD_INVALID", "d7/df5/group__phalMfNtag42xDna__Cust__Err__Codes.html#gac2b602e898571d6700de1daae5231f2d", null ]
];