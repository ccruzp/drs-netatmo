var structphalTop__T2T__t =
[
    [ "pAlT2TDataParams", "d2/d7b/group__phalTop__Sw.html#gae02f53fc4a1d442422e2832f0822aa41", null ],
    [ "bRwa", "d2/d7b/group__phalTop__Sw.html#gae1f7c592bc94fad34fc741397b2d3ee9", null ],
    [ "bTms", "d2/d7b/group__phalTop__Sw.html#ga15be3399e0d591f6a42f278a834d9582", null ],
    [ "bTagMemoryType", "d2/d7b/group__phalTop__Sw.html#ga7a8a74857fff4773b5250aceecee54dc", null ],
    [ "bLockTlvCount", "d2/d7b/group__phalTop__Sw.html#ga61ae168d4b695b8f84751162b093bd0f", null ],
    [ "bMemoryTlvCount", "d2/d7b/group__phalTop__Sw.html#ga700fe640358f8aafb08bee63717a2eb0", null ],
    [ "wNdefHeaderAddr", "d2/d7b/group__phalTop__Sw.html#ga5de7dd838ba16373da444ef2634fec24", null ],
    [ "wNdefMsgAddr", "d2/d7b/group__phalTop__Sw.html#gac23daa62e744ddc8740218402e1e20db", null ],
    [ "asMemCtrlTlv", "d2/d7b/group__phalTop__Sw.html#gae6fcdfb75a87d5c224b8ca77dcef4c35", null ],
    [ "asLockCtrlTlv", "d2/d7b/group__phalTop__Sw.html#ga128438768986161d44105de0f9a474d2", null ],
    [ "sSector", "d2/d7b/group__phalTop__Sw.html#ga58a40e2d710b5430feab415ed417d702", null ]
];