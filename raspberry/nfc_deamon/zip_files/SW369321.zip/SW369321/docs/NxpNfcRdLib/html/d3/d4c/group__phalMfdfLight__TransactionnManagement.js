var group__phalMfdfLight__TransactionnManagement =
[
    [ "PHAL_MFDFLIGHT_COMMIT_TXN_NO_TMC_TMV_RETURNED", "d3/d4c/group__phalMfdfLight__TransactionnManagement.html#ga8cb8954ebed1b6cfd427fbf2a88a87ec", null ],
    [ "PHAL_MFDFLIGHT_COMMIT_TXN_TMC_TMV_RETURNED", "d3/d4c/group__phalMfdfLight__TransactionnManagement.html#ga9c89db54889a694313bba09994cc8690", null ],
    [ "PHAL_MFDFLIGHT_COMMIT_TXN_INCLUDE_OPTION", "d3/d4c/group__phalMfdfLight__TransactionnManagement.html#ga2be256a9ab30b5fceaa9e54bb932d736", null ],
    [ "phalMfdfLight_CommitTransaction", "d3/d4c/group__phalMfdfLight__TransactionnManagement.html#gaf340980e11d1b6a1d304edf48c75970a", null ],
    [ "phalMfdfLight_AbortTransaction", "d3/d4c/group__phalMfdfLight__TransactionnManagement.html#gab73b91b12c4b5f4d8227220152b946e5", null ],
    [ "phalMfdfLight_CommitReaderID", "d3/d4c/group__phalMfdfLight__TransactionnManagement.html#gae89dc6f6349ac367d4bcdb83f96ae973", null ]
];