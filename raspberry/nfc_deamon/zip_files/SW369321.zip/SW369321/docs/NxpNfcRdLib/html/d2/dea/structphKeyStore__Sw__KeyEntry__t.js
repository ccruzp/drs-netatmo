var structphKeyStore__Sw__KeyEntry__t =
[
    [ "wKeyType", "d2/dea/structphKeyStore__Sw__KeyEntry__t.html#aae4d08e13a427ef48ff7912de13efcbd", null ],
    [ "wRefNoKUC", "d2/dea/structphKeyStore__Sw__KeyEntry__t.html#a6d0c017c6be33e3702014c8aef4aea40", null ]
];