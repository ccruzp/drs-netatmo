var structphalVca__Sw__CardTableEntry__t =
[
    [ "wIidIndex", "d3/d83/group__phalVca.html#gad753a77aae4b02f385f8d1c6fdd6fd3f", null ],
    [ "bValid", "d3/d83/group__phalVca.html#gab604f241e3d36bb759efde5ef83eabb5", null ],
    [ "pCardData", "d3/d83/group__phalVca.html#ga7c2ba4dce5f619b2e645a41da0f361c9", null ]
];