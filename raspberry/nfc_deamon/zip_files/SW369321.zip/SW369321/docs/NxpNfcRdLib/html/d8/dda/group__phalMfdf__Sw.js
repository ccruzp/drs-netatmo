var group__phalMfdf__Sw =
[
    [ "phalMfdf_Sw_DataParams_t", "d5/d2f/structphalMfdf__Sw__DataParams__t.html", [
      [ "wId", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#ad48790984fe486a7677384c0b12fa3f4", null ],
      [ "pPalMifareDataParams", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#aabdde9849b05c6aede64ffc406e81432", null ],
      [ "pKeyStoreDataParams", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#ab660e120886e1371138f3f5798db2c0c", null ],
      [ "pCryptoDataParamsEnc", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#a79607bd8b199b21aa4fe876c60e33cef", null ],
      [ "pCryptoRngDataParams", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#a24b68e2bb466f17d259d7f7d9bc47b30", null ],
      [ "pHalDataParams", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#a18bb1e1362eb74df4347e3d015c953fc", null ],
      [ "bSessionKey", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#abe20775d79737f995e583d67a33e950d", null ],
      [ "bKeyNo", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#a67b9f30e09f6e7ebf1683dad633e6e1f", null ],
      [ "bIv", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#a92c765bd9825e82b0029872f57f5b58b", null ],
      [ "bAuthMode", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#aa2b17f15670aec9ec2c6cd1c228a2a4f", null ],
      [ "pAid", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#a4137da43d7df1b93a78f62e045430cda", null ],
      [ "bCryptoMethod", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#a47ec2ea7f7f68501a275ba6e6154d58b", null ],
      [ "bWrappedMode", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#a5986faf7ebca52c4d041f5ccc1d42756", null ],
      [ "wCrc", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#a67ee939307dcf2baeba5f170bce199f8", null ],
      [ "dwCrc", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#ad6579e9f0f2d6220b9a6009ffb473b7d", null ],
      [ "wAdditionalInfo", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#adea2df2b7fef20cc2c2cb91cb5e6668e", null ],
      [ "wPayLoadLen", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#a7c4ac0edd32843589d1eb88ada6f5be8", null ],
      [ "bLastBlockBuffer", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#af867a3608f01b83a4b0d47420a2625f5", null ],
      [ "bLastBlockIndex", "d5/d2f/structphalMfdf__Sw__DataParams__t.html#a1653c2f4719929e41201d414766b7db6", null ]
    ] ],
    [ "PHAL_MFDF_SW_ID", "d8/dda/group__phalMfdf__Sw.html#ga072ede93d34ae8fe02d5dcc538d5af82", null ],
    [ "phalMfdf_Sw_Init", "d8/dda/group__phalMfdf__Sw.html#ga97caa82cef36b91f0234aeaff49265fe", null ]
];