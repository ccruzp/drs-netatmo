var group__phalMfNtag42xDna__TagTamper =
[
    [ "phalMfNtag42XDna_GetTagTamperStatus", "d5/d5e/group__phalMfNtag42xDna__TagTamper.html#gadda79e885e9705a696a93560088f3b66", null ]
];