var structphalVca__Sw__IidTableEntry__t =
[
    [ "wIidIndex", "d3/d83/group__phalVca.html#ga75eaba5b4395488f4c4f159faf670ee6", null ],
    [ "wKeyEncNumber", "d3/d83/group__phalVca.html#ga16334d5263c6cde5d40249dbaac85e34", null ],
    [ "wKeyEncVersion", "d3/d83/group__phalVca.html#gad55787e410da625003f70a10dd6331ba", null ],
    [ "wKeyMacNumber", "d3/d83/group__phalVca.html#ga705085269596369bcc6592d0e4bb449c", null ],
    [ "wKeyMacVersion", "d3/d83/group__phalVca.html#ga7b47611dda0388b0ec46fc3a7717bcf3", null ]
];