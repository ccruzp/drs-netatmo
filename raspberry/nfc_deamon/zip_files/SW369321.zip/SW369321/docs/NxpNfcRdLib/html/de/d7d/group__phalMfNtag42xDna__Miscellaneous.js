var group__phalMfNtag42xDna__Miscellaneous =
[
    [ "PHAL_MFNTAG42XDNA_ADDITIONAL_INFO", "de/d7d/group__phalMfNtag42xDna__Miscellaneous.html#ga95e895fc27e159693b0ffeaf7bbb1074", null ],
    [ "PHAL_MFNTAG42XDNA_WRAPPED_MODE", "de/d7d/group__phalMfNtag42xDna__Miscellaneous.html#gaf12532f0ba45e97938d2f3646134a3a1", null ],
    [ "PHAL_MFNTAG42XDNA_SHORT_LENGTH_APDU", "de/d7d/group__phalMfNtag42xDna__Miscellaneous.html#ga0860c69fd5deec4303c4c41c41bccc3f", null ],
    [ "PHAL_MFNTAG42XDNA_SDM_KEY_TYPE", "de/d7d/group__phalMfNtag42xDna__Miscellaneous.html#ga1c644f5f3b4bea3a44146ef9923418be", null ],
    [ "phalMfNtag42XDna_GetConfig", "de/d7d/group__phalMfNtag42xDna__Miscellaneous.html#ga7d690b055adf09b7b6e675070eb0a229", null ],
    [ "phalMfNtag42XDna_SetConfig", "de/d7d/group__phalMfNtag42xDna__Miscellaneous.html#ga040ae912d085aaf58978e991bea1ef0c", null ],
    [ "phalMfNtag42XDna_ResetAuthentication", "de/d7d/group__phalMfNtag42xDna__Miscellaneous.html#ga64404cce2e6436a4fe9dd99be061f05c", null ],
    [ "phalMfNtag42XDna_CalculateMACSDM", "de/d7d/group__phalMfNtag42xDna__Miscellaneous.html#ga173d18bbdc665dc1ec1323c6856add77", null ],
    [ "phalMfNtag42XDna_DecryptSDMENCFileData", "de/d7d/group__phalMfNtag42xDna__Miscellaneous.html#gaddb348a1c23fed1665614130c67c39e2", null ],
    [ "phalMfNtag42XDna_DecryptSDMPICCData", "de/d7d/group__phalMfNtag42xDna__Miscellaneous.html#gaf2560356d4005f6a1068a76d6039abc3", null ]
];