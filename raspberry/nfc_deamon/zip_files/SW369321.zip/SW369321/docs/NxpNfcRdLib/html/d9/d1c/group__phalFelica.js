var group__phalFelica =
[
    [ "Component : Software", "d1/d99/group__phalFelica__Sw.html", "d1/d99/group__phalFelica__Sw" ],
    [ "PHAL_FELICA_CONFIG_ADD_INFO", "d9/d1c/group__phalFelica.html#ga85bc56fc1ea5fc611ad5c68573b05851", null ],
    [ "PHAL_FELICA_ERR_FELICA", "d9/d1c/group__phalFelica.html#ga5425797ccb2a02730e477294e94b1704", null ],
    [ "PHAL_FELICA_MAX_SERVICES", "d9/d1c/group__phalFelica.html#ga1d9ead763d70116b086805d32db2507a", null ],
    [ "phalFelica_RequestResponse", "d9/d1c/group__phalFelica.html#ga54c87689346b418c5fde2ba0a1aa72d0", null ],
    [ "phalFelica_RequestService", "d9/d1c/group__phalFelica.html#gad783ed8720614faaaceb5f34e905fd55", null ],
    [ "phalFelica_Read", "d9/d1c/group__phalFelica.html#gaa4aaa691fcbc54e95f9fcc5b39078a33", null ],
    [ "phalFelica_Write", "d9/d1c/group__phalFelica.html#ga460e641a7149cb88c12f51b15af3da17", null ],
    [ "phalFelica_GetConfig", "d9/d1c/group__phalFelica.html#ga6f74b496688d71ea3f8f210484fa427a", null ],
    [ "phalFelica_ActivateCard", "d9/d1c/group__phalFelica.html#gaeaae2605b6e0cbd79c6fc2687dffb1f7", null ]
];