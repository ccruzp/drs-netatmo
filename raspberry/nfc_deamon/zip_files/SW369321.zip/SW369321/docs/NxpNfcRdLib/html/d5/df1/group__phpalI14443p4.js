var group__phpalI14443p4 =
[
    [ "Component : Software", "d5/d84/group__phpalI14443p4__Sw.html", "d5/d84/group__phpalI14443p4__Sw" ],
    [ "PHPAL_I14443P4_CID_MAX", "d5/df1/group__phpalI14443p4.html#gadd42f283d58403d4604de16b4b6a23c2", null ],
    [ "PHPAL_I14443P4_FWI_MAX", "d5/df1/group__phpalI14443p4.html#ga24fd34c1c86cf47043e3d19ec9b1833d", null ],
    [ "PHPAL_I14443P4_FRAMESIZE_MAX", "d5/df1/group__phpalI14443p4.html#gab107f860bf388f5a074b2c72d0c415c4", null ],
    [ "PHPAL_I14443P4_CONFIG_BLOCKNO", "d5/df1/group__phpalI14443p4.html#ga01d273105deb4e10036df5f9f8be62f2", null ],
    [ "PHPAL_I14443P4_CONFIG_CID", "d5/df1/group__phpalI14443p4.html#ga0dda22f34d89a52705a99e846ac5d2bd", null ],
    [ "PHPAL_I14443P4_CONFIG_NAD", "d5/df1/group__phpalI14443p4.html#ga7d91cf382cc677c6a8449ac9b2d2ceba", null ],
    [ "PHPAL_I14443P4_CONFIG_FWI", "d5/df1/group__phpalI14443p4.html#ga2b472f1f8d866cc7ea547b93bf8c9047", null ],
    [ "PHPAL_I14443P4_CONFIG_FSI", "d5/df1/group__phpalI14443p4.html#ga58bc6a73130f6d4f1334a968ba420fd5", null ],
    [ "PHPAL_I14443P4_CONFIG_MAXRETRYCOUNT", "d5/df1/group__phpalI14443p4.html#ga54c456e8f13f4c66b8f4c6d801441a60", null ],
    [ "PHPAL_I14443P4_CONFIG_OPE_MODE", "d5/df1/group__phpalI14443p4.html#ga5f9d27da65c1ac2eb8dc08eefd986f12", null ],
    [ "phpalI14443p4_SetProtocol", "d5/df1/group__phpalI14443p4.html#ga4d0b38c74188ba206e4bbfe1e6101c81", null ],
    [ "phpalI14443p4_ResetProtocol", "d5/df1/group__phpalI14443p4.html#gaa65f61cee7ef5ff8e39dfb5c10d932e3", null ],
    [ "phpalI14443p4_Deselect", "d5/df1/group__phpalI14443p4.html#ga69c73085908678c0844c28233a8c7c84", null ],
    [ "phpalI14443p4_PresCheck", "d5/df1/group__phpalI14443p4.html#gabc0fa1776e3c61a8c90df2171fc232ef", null ],
    [ "phpalI14443p4_Exchange", "d5/df1/group__phpalI14443p4.html#gae8e896b2c53384ca31b854e975c476d3", null ],
    [ "phpalI14443p4_SetConfig", "d5/df1/group__phpalI14443p4.html#gaefcdbeee282bb36703f4b8dded07815b", null ],
    [ "phpalI14443p4_GetConfig", "d5/df1/group__phpalI14443p4.html#ga216f51725ef173e2bbd640f0b39c5872", null ]
];