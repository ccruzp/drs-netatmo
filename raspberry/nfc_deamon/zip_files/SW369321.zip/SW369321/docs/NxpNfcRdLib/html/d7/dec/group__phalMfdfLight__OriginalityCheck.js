var group__phalMfdfLight__OriginalityCheck =
[
    [ "phalMfdfLight_ReadSign", "d7/dec/group__phalMfdfLight__OriginalityCheck.html#ga0a38546636ad28fc2d55625546065fcf", null ]
];