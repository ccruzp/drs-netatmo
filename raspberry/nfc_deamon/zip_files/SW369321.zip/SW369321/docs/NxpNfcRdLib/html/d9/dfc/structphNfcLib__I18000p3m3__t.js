var structphNfcLib__I18000p3m3__t =
[
    [ "bCommand", "d9/dfc/structphNfcLib__I18000p3m3__t.html#ab0b500340be60ce3a96e629299247f6f", null ],
    [ "bOption", "d9/dfc/structphNfcLib__I18000p3m3__t.html#ac92362d25dcbf18107a3b6e4b8f32879", null ],
    [ "bMemBank", "d9/dfc/structphNfcLib__I18000p3m3__t.html#a59cf2b9895ce6b1fe8f06ba25c76dbbf", null ],
    [ "bReadLock", "d9/dfc/structphNfcLib__I18000p3m3__t.html#a58e06244aa708406b7ef0509f648cd76", null ],
    [ "pWordPtr", "d9/dfc/structphNfcLib__I18000p3m3__t.html#a4a45edf1ed5a961644b47e1ae66740c7", null ],
    [ "bWordPtrLength", "d9/dfc/structphNfcLib__I18000p3m3__t.html#a641ae9cb454086535ee46786ece5c0fd", null ],
    [ "bWordCount", "d9/dfc/structphNfcLib__I18000p3m3__t.html#a2b1ae57bc680f2ec8252b98cd1957607", null ],
    [ "pPassword", "d9/dfc/structphNfcLib__I18000p3m3__t.html#a66cc70a9e36f6ac154f4f3a90f140dde", null ],
    [ "bRecom", "d9/dfc/structphNfcLib__I18000p3m3__t.html#ae632944089b1974edf89a5ffe330ae04", null ],
    [ "pMask", "d9/dfc/structphNfcLib__I18000p3m3__t.html#a20d2cfe394051b648de0bb3f867f22aa", null ],
    [ "pAction", "d9/dfc/structphNfcLib__I18000p3m3__t.html#aa5acb9f5a6140a15b7b2b2a6a203e2a0", null ],
    [ "pBlockPtr", "d9/dfc/structphNfcLib__I18000p3m3__t.html#a8af08db918b88e7df4dfa0290d0a8833", null ],
    [ "bBlockPtrLength", "d9/dfc/structphNfcLib__I18000p3m3__t.html#a4bfd9ae1408a82e17373b4a77f1e5d98", null ],
    [ "bBlockRange", "d9/dfc/structphNfcLib__I18000p3m3__t.html#a4a08f2cd4f6d1d0f2735fe3645fd0c58", null ],
    [ "pHandle", "d9/dfc/structphNfcLib__I18000p3m3__t.html#ab220a69002697441e8fd2e58e01342fa", null ],
    [ "pUii", "d9/dfc/structphNfcLib__I18000p3m3__t.html#a5e727ba345324825a2fb9ac277594096", null ],
    [ "wUiiMaskLength", "d9/dfc/structphNfcLib__I18000p3m3__t.html#a312939143077d1a2fa8a480db2f58870", null ],
    [ "pBuffer", "d9/dfc/structphNfcLib__I18000p3m3__t.html#a35edc56279b04ce5dec96c97063feb53", null ]
];