var structphalTop__T5T__t =
[
    [ "pAlI15693DataParams", "d2/d7b/group__phalTop__Sw.html#ga92f532872675980fbf48657780318224", null ],
    [ "bRwa", "d2/d7b/group__phalTop__Sw.html#gaa4d887147dd1134e38c437107b38b190", null ],
    [ "bTerminatorTlvPresence", "d2/d7b/group__phalTop__Sw.html#gaca70e25407302090f72a423fc1ebb126", null ],
    [ "bMbRead", "d2/d7b/group__phalTop__Sw.html#ga1460e1d74c00bf6412deedf2a987fca0", null ],
    [ "bLockBlock", "d2/d7b/group__phalTop__Sw.html#ga2a8578a5d857db47ac533cd7dece715b", null ],
    [ "bSplFrm", "d2/d7b/group__phalTop__Sw.html#gaa7b2ce069ced5b5234370a6237724dbc", null ],
    [ "bExtendedCommandSupport", "d2/d7b/group__phalTop__Sw.html#gab9a994b91cda6e2c14ad6c13e5970456", null ],
    [ "bOptionFlag", "d2/d7b/group__phalTop__Sw.html#ga7bdfc4578018f3de74d304a8da04e1a5", null ],
    [ "wMlen", "d2/d7b/group__phalTop__Sw.html#ga02a1c82a311f0b8e72e0cc0c3f06f30f", null ],
    [ "wNdefHeaderAddr", "d2/d7b/group__phalTop__Sw.html#ga4ffad20ab0fd67093576f0f520e60cfa", null ],
    [ "wNdefMsgAddr", "d2/d7b/group__phalTop__Sw.html#ga9ff455eb842b3f6ec4891c6555b885df", null ],
    [ "bBlockSize", "d2/d7b/group__phalTop__Sw.html#ga875a8fbaf9874540f83e9a6045547912", null ],
    [ "bMaxBlockNum", "d2/d7b/group__phalTop__Sw.html#gaa6e71bbe1c3f806590083b1653448b23", null ]
];