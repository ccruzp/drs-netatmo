var group__phalMfNtag42xDna__OriginalityCheck =
[
    [ "phalMfNtag42XDna_ReadSign", "d1/d50/group__phalMfNtag42xDna__OriginalityCheck.html#ga37a35093076dc0a666f2dba10562426b", null ]
];