var structphnpSnep__Sw__DataParams__t =
[
    [ "wId", "d4/d9c/structphnpSnep__Sw__DataParams__t.html#a85d45680479232dbed6c865ecd5528bb", null ],
    [ "plnLlcpDataParams", "d4/d9c/structphnpSnep__Sw__DataParams__t.html#a8f5df530c1a7acd76c638787cbcbc3c0", null ],
    [ "psSocket", "d4/d9c/structphnpSnep__Sw__DataParams__t.html#a0b5c437862543e2a356dbbbd8c6fd6f3", null ],
    [ "bSnepVersion", "d4/d9c/structphnpSnep__Sw__DataParams__t.html#affe488f5e6587d26a358dc777b31fab0", null ],
    [ "eServerType", "d4/d9c/structphnpSnep__Sw__DataParams__t.html#a760305dfa036043aaff827d8f929a9d8", null ]
];