var structphacDiscLoop__Sw__TypeB__Info__t =
[
    [ "bTotalTagsFound", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#ab7576bdee3ab29d30be98c938f3da4b3", null ],
    [ "bAfiReq", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#a8d7d3611cf00597814bf561086a24a40", null ],
    [ "bExtendedAtqBbit", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#a4acaa581d5ac963e5ce671eb9ed7d2e1", null ],
    [ "bAdvFeaturesBit", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#ab817aa888ba90e53afccefa4e9bbc60d", null ],
    [ "bFsdi", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#a65e212bee8a4b259f155f61e0f1b8b89", null ],
    [ "bCid", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#a9ef595724fa3b185353de551bef06dc6", null ],
    [ "bNad", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#a93e793dd2c667bdb25a2cf0542475e62", null ],
    [ "bDri", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#a462ea3d74dedaf5d36cf0c3196c60029", null ],
    [ "bDsi", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#a359f081146c9ab8a3c76f0fbe8a05b24", null ],
    [ "aPupi", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#ac53d44ca9fa589513df1de5256ba80f9", null ],
    [ "aAtqB", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#a793982593d9ee62881d5c6189998f21b", null ],
    [ "bAtqBLength", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#a0da91043edb0d7acc41de78eab5470dc", null ],
    [ "bSupportType4B", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#a96ddeda50996e58b1ff665569327137f", null ],
    [ "aTypeB_I3P3", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#acaf3b44215fd4e814e9a4785cca610c4", null ],
    [ "bMbli", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#a5a76701e865fc6b3a524d71ce9dafe42", null ],
    [ "bParam1", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#a161ff06022f80d534840e1366808285c", null ],
    [ "sTypeB_I3P4", "d3/d95/structphacDiscLoop__Sw__TypeB__Info__t.html#a8d3be48177cab8586434319e92e52cd0", null ]
];