var structphalTop__T4T__t =
[
    [ "pAlT4TDataParams", "d2/d7b/group__phalTop__Sw.html#gaa9e95372693c9a7ef009e6530b235267", null ],
    [ "aNdefFileID", "d2/d7b/group__phalTop__Sw.html#ga7ec07f3bf3706b4c5aa85d1eec4d4eea", null ],
    [ "bRa", "d2/d7b/group__phalTop__Sw.html#ga91598212a9f051e28dbbe16a0d8c0e7f", null ],
    [ "bWa", "d2/d7b/group__phalTop__Sw.html#ga06ebea5cd47b0c5a220271ff5c38d243", null ],
    [ "bCurrentSelectedFile", "d2/d7b/group__phalTop__Sw.html#gaabd7a4f7b638c173d520d5c9dfab89d6", null ],
    [ "wMLe", "d2/d7b/group__phalTop__Sw.html#gabb05ccfdd0b9082533804db7c6973d12", null ],
    [ "wMLc", "d2/d7b/group__phalTop__Sw.html#gac3666b57768ff1c8473ad01f5bf781c2", null ],
    [ "wCCLEN", "d2/d7b/group__phalTop__Sw.html#gae9346092dd490c9a5e5aba179cfcf7a0", null ],
    [ "wMaxFileSize", "d2/d7b/group__phalTop__Sw.html#ga8e80e6a0d697fb71838b3453ea49fd2f", null ]
];