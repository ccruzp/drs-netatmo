var group__phalMfdfLight__MemoryConfiguration =
[
    [ "PHAL_MFDFLIGHT_SET_CONFIG_OPTION0", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#gaa954d31514f5d0eabf73a8b55ca0283d", null ],
    [ "PHAL_MFDFLIGHT_SET_CONFIG_OPTION1", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#ga58769c1e1e4e90d9c376404826bb0c01", null ],
    [ "PHAL_MFDFLIGHT_SET_CONFIG_OPTION2", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#ga7365c4b8854d47ec0e7013660df30ee6", null ],
    [ "PHAL_MFDFLIGHT_SET_CONFIG_OPTION3", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#ga48935ee7d199ccec08adfdaf5cd8e630", null ],
    [ "PHAL_MFDFLIGHT_SET_CONFIG_OPTION4", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#ga825b94ff4224eb4e318654dc9e4d8497", null ],
    [ "PHAL_MFDFLIGHT_SET_CONFIG_OPTION5", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#ga804e3c29af4babc963ad49c40af7ec7b", null ],
    [ "PHAL_MFDFLIGHT_SET_CONFIG_OPTION6", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#gaed0b3dd6e10439bfbc6d599ab93e1a54", null ],
    [ "PHAL_MFDFLIGHT_SET_CONFIG_OPTION8", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#ga94d1a2ebd1ec453e2462357af5f7e306", null ],
    [ "PHAL_MFDFLIGHT_SET_CONFIG_OPTION9", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#ga810f4ea68e1a56f885621bed1834dcdb", null ],
    [ "PHAL_MFDFLIGHT_SET_CONFIG_OPTION10", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#ga9b9bc924ee042db1fe0d5b0980744ecf", null ],
    [ "PHAL_MFDFLIGHT_SET_CONFIG_OPTION11", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#ga98403504857826c9fd46e9c0dfbbd9e8", null ],
    [ "phalMfdfLight_SetConfiguration", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#gad444349f145932380ad3191e312636d3", null ],
    [ "phalMfdfLight_GetCardUID", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#ga3150b9008c61c2ee817f4d323f6e7a02", null ],
    [ "phalMfdfLight_GetVersion", "d0/d19/group__phalMfdfLight__MemoryConfiguration.html#gaa61498bac508b2d19a04af0f071f2d8c", null ]
];