var group__phpalI14443p4mC__Sw =
[
    [ "phpalI14443p4mC_Sw_DataParams_t", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html", [
      [ "wId", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#ab48126a7346b12f7ccf639fec36dc504", null ],
      [ "wLastTxLen", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#ac37298e89d0d89be8e769edea607bf98", null ],
      [ "pHalDataParams", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#aa9df73098740934bdeec3395486843e0", null ],
      [ "bDisableWtx", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a76dc9731faf75d9d5b2732c7c0ba3ea5", null ],
      [ "bWtx", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a4fe8a7138045170aae479858e500bfdc", null ],
      [ "bFsdi", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a63e958bc94a2fdb4692d722588faed75", null ],
      [ "bFsci", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a79ac774181864a28e9c51581aad0600e", null ],
      [ "bDr", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#aed59601802a766fee279a829a2c07366", null ],
      [ "bDs", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#ae9f0f0f73ce5e5729b90b0a8b1433465", null ],
      [ "bUnequalDrDs", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a15711de3819eea4d216b28a20db68fe9", null ],
      [ "bFwi", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#ab7f01f69a5dc783a7a2cdf830e2433b1", null ],
      [ "bSfgi", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a2fc9c6add88cad5c7499f5ba2909777c", null ],
      [ "bCidEnable", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#ada6a6294fbd20a8528497355d3aee208", null ],
      [ "bCidPresence", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#aa1a0252b308679a89e6f767f2f24137b", null ],
      [ "bCid", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a1f32ad56fd5ee2f49f841c538caae282", null ],
      [ "bNadEnable", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#aa93981449a4186fe1137ee07c599adea", null ],
      [ "bNadPresence", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#ae746c80418b27ebe8b361cd76629f4f4", null ],
      [ "bNad", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a7ea590a4a83fe6fe149d50a7d139eb12", null ],
      [ "bStateNow", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#ab30b0c0f874acf42e0904e72bec39da2", null ],
      [ "bBlockNr", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a4d998c1fd5b9de5a0a28c54ef87ca9dc", null ],
      [ "bChainingRx", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a5a594c6e9a6f36b3045917361be9b5ed", null ],
      [ "bChainingTx", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#ab0c733bbeac9a14cdbe12562b98da2de", null ],
      [ "bOpMode", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a004bcdc6cd7b69194b5cda119e7cb62d", null ],
      [ "wWtDelta", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a124e6e27b7edb01a0b867484c1ae6026", null ],
      [ "bWtPercentage", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a34612636d6a1a474864ac9740e11e5e4", null ],
      [ "pWtxTimerCallback", "d3/d6c/structphpalI14443p4mC__Sw__DataParams__t.html#a45b84a904773d3fdeec21da2e3bc22c5", null ]
    ] ],
    [ "PHPAL_I14443P4MC_SW_ID", "d9/d1f/group__phpalI14443p4mC__Sw.html#gaf93fba33ad145f7d24840c6d38fc3473", null ],
    [ "pWtxTimerCallback", "d9/d1f/group__phpalI14443p4mC__Sw.html#ga2b0e301825cf1cf27c2c44ac570425e6", null ],
    [ "phpalI14443p4mC_Sw_Init", "d9/d1f/group__phpalI14443p4mC__Sw.html#gae652f9ba3d667faa74d8591e76028948", null ]
];