var group__phalFelica__Sw =
[
    [ "phalFelica_Sw_DataParams_t", "d3/dd2/structphalFelica__Sw__DataParams__t.html", [
      [ "wId", "d3/dd2/structphalFelica__Sw__DataParams__t.html#a36b27ac56e05463b4b507cde99d2bfa6", null ],
      [ "pPalFelicaDataParams", "d3/dd2/structphalFelica__Sw__DataParams__t.html#ab162708037d05dffe2232ddd72d320b5", null ],
      [ "wAdditionalInfo", "d3/dd2/structphalFelica__Sw__DataParams__t.html#a316e839e11e020259a1418102797b6fa", null ]
    ] ],
    [ "PHAL_FELICA_SW_ID", "d1/d99/group__phalFelica__Sw.html#gaeb6157a4eb4b8c045610199156fb6550", null ],
    [ "phalFelica_Sw_Init", "d1/d99/group__phalFelica__Sw.html#gaa3b82b88e02fe6c5375dd9db1fc57b6e", null ]
];