var group__phpalI14443p3a =
[
    [ "Component : Software", "df/d5d/group__phpalI14443p3a__Sw.html", "df/d5d/group__phpalI14443p3a__Sw" ],
    [ "PHPAL_I14443P3A_CASCADE_LEVEL_1", "d2/d0d/group__phpalI14443p3a.html#ga37cda913ded551140b6dbd8c477ba77c", null ],
    [ "PHPAL_I14443P3A_CASCADE_LEVEL_2", "d2/d0d/group__phpalI14443p3a.html#ga6d316bb29a7ead022d027a1fc2be70bf", null ],
    [ "PHPAL_I14443P3A_CASCADE_LEVEL_3", "d2/d0d/group__phpalI14443p3a.html#ga97d2e5e2f58e6aebc79cfa965447af5e", null ],
    [ "PHPAL_I14443P3A_TIMEOUT_DEFAULT_MS", "d2/d0d/group__phpalI14443p3a.html#ga9acbd7b13a27a68ff00293b2caf83dc9", null ],
    [ "PHPAL_I14443P3A_USE_REQA", "d2/d0d/group__phpalI14443p3a.html#gae4bb12b92f61a361cf47ba1b0d9cfe1b", null ],
    [ "PHPAL_I14443P3A_USE_WUPA", "d2/d0d/group__phpalI14443p3a.html#gab26daadd9a711a2710e9e80e81a0adf1", null ],
    [ "PHPAL_I14443P3A_CONFIG_OPE_MODE", "d2/d0d/group__phpalI14443p3a.html#gaddbfcb9b6369f9f68c352632e7299324", null ],
    [ "PHPAL_I14443P3A_CONFIG_POLL_CMD", "d2/d0d/group__phpalI14443p3a.html#ga86692cabb2988ada77809216f22b8947", null ],
    [ "PHPAL_I14443P3A_CONFIG_TIMEOUT_VALUE_US", "d2/d0d/group__phpalI14443p3a.html#ga209e101faef10e81c884db77acb07c83", null ],
    [ "phpalI14443p3a_SetConfig", "d2/d0d/group__phpalI14443p3a.html#ga11373b26e9f67b4ee38993a96f7d9692", null ],
    [ "phpalI14443p3a_GetConfig", "d2/d0d/group__phpalI14443p3a.html#ga22d8fae001207acbb0d7e6d6dd2b08f9", null ],
    [ "phpalI14443p3a_RequestA", "d2/d0d/group__phpalI14443p3a.html#gaddc306d340bf0c2df71a257a50021a14", null ],
    [ "phpalI14443p3a_WakeUpA", "d2/d0d/group__phpalI14443p3a.html#gaad3dff17e4950505075d86887b02545b", null ],
    [ "phpalI14443p3a_HaltA", "d2/d0d/group__phpalI14443p3a.html#ga73b660ada7b0e473384f0aaf821c2f03", null ],
    [ "phpalI14443p3a_Anticollision", "d2/d0d/group__phpalI14443p3a.html#ga1f1c95c1e7225abf98c7975a0d12b78a", null ],
    [ "phpalI14443p3a_Select", "d2/d0d/group__phpalI14443p3a.html#gaf78f9b06af78803dbdbf4af44243ce77", null ],
    [ "phpalI14443p3a_ActivateCard", "d2/d0d/group__phpalI14443p3a.html#ga107fe28f01cedc0061a091307542e9b7", null ],
    [ "phpalI14443p3a_Exchange", "d2/d0d/group__phpalI14443p3a.html#gad1cd7ef9896da7b89c89fc7fc102a515", null ],
    [ "phpalI14443p3a_GetSerialNo", "d2/d0d/group__phpalI14443p3a.html#ga4a7ae7aaa4eff5a111dcfd2a9737aed7", null ]
];