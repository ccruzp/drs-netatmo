var group__phalMfNtag42xDna__KeyManagement =
[
    [ "PHAL_MFNTAG42XDNA_CHGKEY_NO_DIVERSIFICATION", "d6/de7/group__phalMfNtag42xDna__KeyManagement.html#ga30d2ad2334aecd870c6ee369bfed4b4c", null ],
    [ "PHAL_MFNTAG42XDNA_CHGKEY_DIV_NEW_KEY", "d6/de7/group__phalMfNtag42xDna__KeyManagement.html#gad6f9f18c7884e57535ad57a0f76a5b93", null ],
    [ "PHAL_MFNTAG42XDNA_CHGKEY_DIV_OLD_KEY", "d6/de7/group__phalMfNtag42xDna__KeyManagement.html#ga4c96e4850ecff232cee1da4b2651f60c", null ],
    [ "PHAL_MFNTAG42XDNA_CHGKEY_DIV_NEW_KEY_ONERND", "d6/de7/group__phalMfNtag42xDna__KeyManagement.html#gaaa04e02fc7d9c5a0b37efb4db2c6e282", null ],
    [ "PHAL_MFNTAG42XDNA_CHGKEY_DIV_OLD_KEY_ONERND", "d6/de7/group__phalMfNtag42xDna__KeyManagement.html#ga20395ccef41d86440e3f0fed2bfa79a3", null ],
    [ "PHAL_MFNTAG42XDNA_CHGKEY_DIV_METHOD_CMAC", "d6/de7/group__phalMfNtag42xDna__KeyManagement.html#ga13f064717d21cd20be54ff2dab72e701", null ],
    [ "phalMfNtag42XDna_ChangeKey", "d6/de7/group__phalMfNtag42xDna__KeyManagement.html#ga9fe08763d621d174366af8b38cff9c5c", null ],
    [ "phalMfNtag42XDna_GetKeyVersion", "d6/de7/group__phalMfNtag42xDna__KeyManagement.html#ga6744274a3f41176d0f26ae8b43cc70ba", null ]
];