var structphlnLlcp__Socket__Seq__t =
[
    [ "bSendState_Vs", "df/db5/structphlnLlcp__Socket__Seq__t.html#aa50d3359b3f0106fa4031ef880ad5938", null ],
    [ "bSendAck_Vsa", "df/db5/structphlnLlcp__Socket__Seq__t.html#a93a87bf986183ae10b46626cad634597", null ],
    [ "bRxState_Vr", "df/db5/structphlnLlcp__Socket__Seq__t.html#a68538e91624b20dfeec1a1b5e658efaa", null ],
    [ "bRxAck_Vra", "df/db5/structphlnLlcp__Socket__Seq__t.html#a92fb2435167625de141c8e78312f443c", null ]
];