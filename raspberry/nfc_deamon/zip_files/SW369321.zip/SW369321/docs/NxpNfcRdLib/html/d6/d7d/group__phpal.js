var group__phpal =
[
    [ "ISO/IEC 14443-3A", "d2/d0d/group__phpalI14443p3a.html", "d2/d0d/group__phpalI14443p3a" ],
    [ "ISO/IEC 14443-3B", "d8/d89/group__phpalI14443p3b.html", "d8/d89/group__phpalI14443p3b" ],
    [ "ISO/IEC 14443-4A", "df/dda/group__phpalI14443p4a.html", "df/dda/group__phpalI14443p4a" ],
    [ "ISO/IEC 14443-4", "d5/df1/group__phpalI14443p4.html", "d5/df1/group__phpalI14443p4" ],
    [ "MIFARE product", "da/d8e/group__phpalMifare.html", "da/d8e/group__phpalMifare" ],
    [ "ISO/IEC 14443-4mC", "d9/ddf/group__phpalI14443p4mC.html", "d9/ddf/group__phpalI14443p4mC" ],
    [ "FeliCa", "d8/d88/group__phpalFelica.html", "d8/d88/group__phpalFelica" ],
    [ "ISO/IEC 15693 / ISO/IEC 18000-3M1", "d9/dcf/group__phpalSli15693.html", "d9/dcf/group__phpalSli15693" ],
    [ "ISO/IEC 18000-3 Mode3", "d1/deb/group__phpalI18000p3m3.html", "d1/deb/group__phpalI18000p3m3" ],
    [ "ISO/IEC 18092 Mode Initiator", "d6/d42/group__phpalI18092mPI.html", "d6/d42/group__phpalI18092mPI" ],
    [ "ISO/IEC 18092 Mode Target", "d3/df9/group__phpalI18092mT.html", "d3/df9/group__phpalI18092mT" ]
];