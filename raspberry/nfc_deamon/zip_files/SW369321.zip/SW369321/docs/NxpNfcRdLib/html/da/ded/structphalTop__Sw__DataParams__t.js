var structphalTop__Sw__DataParams__t =
[
    [ "wId", "d2/d7b/group__phalTop__Sw.html#ga92883f700fdc13962a398cf3f862ef4f", null ],
    [ "bTagType", "d2/d7b/group__phalTop__Sw.html#ga2dcc6cb9e10c275ebe76c019c975472c", null ],
    [ "bVno", "d2/d7b/group__phalTop__Sw.html#gafda57ce1c16346e571838065fcfdbaf8", null ],
    [ "bTagState", "d2/d7b/group__phalTop__Sw.html#ga493b602e7dde8c0068f98b0f0da36ea6", null ],
    [ "wNdefLength", "d2/d7b/group__phalTop__Sw.html#ga38314d5452faf42fb47029be9750f024", null ],
    [ "wMaxNdefLength", "d2/d7b/group__phalTop__Sw.html#ga9eeaad70bc49797b2e24e4d27c588440", null ],
    [ "pTopTagsDataParams", "d2/d7b/group__phalTop__Sw.html#ga4280a4e499248ddda335295a6ed810bb", null ],
    [ "salTop_T1T", "d2/d7b/group__phalTop__Sw.html#ga4c2fe911a779325fb7cda6b28cdfce49", null ],
    [ "salTop_T2T", "d2/d7b/group__phalTop__Sw.html#gab1ef29d6e6f505b2de0f7aa9002dfbed", null ],
    [ "salTop_T3T", "d2/d7b/group__phalTop__Sw.html#ga924fe599742c4335c794c3642648916a", null ],
    [ "salTop_T4T", "d2/d7b/group__phalTop__Sw.html#ga9a780abd675bee91272cf81399b3c7f1", null ],
    [ "salTop_T5T", "d2/d7b/group__phalTop__Sw.html#ga3602685432378bcf3192d4138ef3f902", null ],
    [ "salTop_MfcTop", "d2/d7b/group__phalTop__Sw.html#ga329dc24f9c56f2e803081ec5fd9e757f", null ]
];