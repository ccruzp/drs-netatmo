var structphalTop__T1T__t =
[
    [ "pAlT1TDataParams", "d2/d7b/group__phalTop__Sw.html#ga17ff930c804550a23bc22bfe43aca873", null ],
    [ "bRwa", "d2/d7b/group__phalTop__Sw.html#ga9cfba78bc85482d678de3c094fbbff38", null ],
    [ "bTms", "d2/d7b/group__phalTop__Sw.html#ga6876ca035b71880ae3fd47c42c93d09b", null ],
    [ "bTagMemoryType", "d2/d7b/group__phalTop__Sw.html#ga6b05e6c88fcca31b2e32d3ae5162ef52", null ],
    [ "bTerminatorTlvPresence", "d2/d7b/group__phalTop__Sw.html#ga180367b9ac447f4fa3db7a57e5ab5c8d", null ],
    [ "bLockTlvCount", "d2/d7b/group__phalTop__Sw.html#gaec81a0b777b7ee0898c6dd24b198007c", null ],
    [ "bMemoryTlvCount", "d2/d7b/group__phalTop__Sw.html#ga3f93eabade8709c0ff57091efe215c5f", null ],
    [ "wNdefHeaderAddr", "d2/d7b/group__phalTop__Sw.html#ga8b5f58ebe39b8be13a48c83fd84be132", null ],
    [ "wNdefMsgAddr", "d2/d7b/group__phalTop__Sw.html#ga4dcf93bfa216e5fc26e8210f8347fa36", null ],
    [ "bUid", "d2/d7b/group__phalTop__Sw.html#ga5dcab06c5a157c9fee4c944f6037774c", null ],
    [ "asMemCtrlTlv", "d2/d7b/group__phalTop__Sw.html#ga0f958666448ed38e80cd7fe6a09ffedb", null ],
    [ "asLockCtrlTlv", "d2/d7b/group__phalTop__Sw.html#ga459e29d121929b5ca56eead09101068f", null ],
    [ "sSegment", "d2/d7b/group__phalTop__Sw.html#gab647a25dafa49fd2659abd8204b9ab00", null ]
];