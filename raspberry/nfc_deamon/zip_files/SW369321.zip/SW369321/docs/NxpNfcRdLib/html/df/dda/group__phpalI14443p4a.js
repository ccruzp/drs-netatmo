var group__phpalI14443p4a =
[
    [ "Component : Software", "d1/d7c/group__phpalI14443p4a__Sw.html", "d1/d7c/group__phpalI14443p4a__Sw" ],
    [ "PHPAL_I14443P4A_CONFIG_OPE_MODE", "df/dda/group__phpalI14443p4a.html#ga4cb3dff0b902cd483f407b2a5e0ad75b", null ],
    [ "PHPAL_I14443P4A_CONFIG_RATS_RETRY_COUNT", "df/dda/group__phpalI14443p4a.html#ga6bf583bef57ead1ce0873bd9299d228e", null ],
    [ "PHPAL_I14443P4A_NFC_FRAMESIZE_MAX", "df/dda/group__phpalI14443p4a.html#ga94a2d5b655d4e65babe7366c80163b12", null ],
    [ "PHPAL_I14443P4A_DATARATE_106", "df/dda/group__phpalI14443p4a.html#ga32828e6c2ffee743982435ccdcd64419", null ],
    [ "PHPAL_I14443P4A_DATARATE_212", "df/dda/group__phpalI14443p4a.html#ga481232da8e8ced39610290d910aa6030", null ],
    [ "PHPAL_I14443P4A_DATARATE_424", "df/dda/group__phpalI14443p4a.html#gace900514c4f87c0c3d4c3a37830455dc", null ],
    [ "PHPAL_I14443P4A_DATARATE_848", "df/dda/group__phpalI14443p4a.html#ga92c06a64e6534aef3502f7d0aaf37eb0", null ],
    [ "PHPAL_I14443P4A_RATS_RETRY_MAX", "df/dda/group__phpalI14443p4a.html#ga84341404b0b2a942c97904965efab0f0", null ],
    [ "PHPAL_I14443P4A_RATS_RETRY_MIN", "df/dda/group__phpalI14443p4a.html#ga180d41c1d6ffcd975124bb18d7154dce", null ],
    [ "phpalI14443p4a_Rats", "df/dda/group__phpalI14443p4a.html#ga3348f9c863f0873bdb75b9d3aedc7a47", null ],
    [ "phpalI14443p4a_Pps", "df/dda/group__phpalI14443p4a.html#ga8ab3710e8324fa9d8e77498851831f0e", null ],
    [ "phpalI14443p4a_ActivateCard", "df/dda/group__phpalI14443p4a.html#gab2af974cf3d9534523435315a9bb820d", null ],
    [ "phpalI14443p4a_GetProtocolParams", "df/dda/group__phpalI14443p4a.html#ga6630a1bee848e7328b09e92388a8d74b", null ],
    [ "phpalI14443p4a_SetConfig", "df/dda/group__phpalI14443p4a.html#ga763eb90f6c8b15d7d381b9e1ac0fe021", null ]
];