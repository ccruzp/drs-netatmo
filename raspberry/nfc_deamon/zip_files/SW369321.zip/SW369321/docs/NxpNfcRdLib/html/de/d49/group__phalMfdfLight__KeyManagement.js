var group__phalMfdfLight__KeyManagement =
[
    [ "PHAL_MFDFLIGHT_CHGKEY_NO_DIVERSIFICATION", "de/d49/group__phalMfdfLight__KeyManagement.html#ga13eb39a03954b72bb4134c6a970f96f0", null ],
    [ "PHAL_MFDFLIGHT_CHGKEY_DIV_NEW_KEY", "de/d49/group__phalMfdfLight__KeyManagement.html#ga1b3fed3c29cc427c04c449eb7cf5120b", null ],
    [ "PHAL_MFDFLIGHT_CHGKEY_DIV_OLD_KEY", "de/d49/group__phalMfdfLight__KeyManagement.html#ga5899bfd34e434567e1c940ef0d2481b0", null ],
    [ "PHAL_MFDFLIGHT_CHGKEY_DIV_NEW_KEY_ONERND", "de/d49/group__phalMfdfLight__KeyManagement.html#ga0007abfcba481cc6983b2428cc793d1a", null ],
    [ "PHAL_MFDFLIGHT_CHGKEY_DIV_OLD_KEY_ONERND", "de/d49/group__phalMfdfLight__KeyManagement.html#gaa4c29b3deaa8ed04fcba1c6acf026799", null ],
    [ "PHAL_MFDFLIGHT_CHGKEY_DIV_METHOD_CMAC", "de/d49/group__phalMfdfLight__KeyManagement.html#gac8af2a70d63b4f970a949cfeea0630c9", null ],
    [ "phalMfdfLight_ChangeKey", "de/d49/group__phalMfdfLight__KeyManagement.html#ga329b30cde13744b60cc47beba128a830", null ],
    [ "phalMfdfLight_GetKeyVersion", "de/d49/group__phalMfdfLight__KeyManagement.html#ga43af2af003f5bbd05277189086788c8b", null ]
];