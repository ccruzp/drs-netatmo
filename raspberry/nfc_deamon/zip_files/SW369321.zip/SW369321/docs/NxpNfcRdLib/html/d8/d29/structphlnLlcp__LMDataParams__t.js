var structphlnLlcp__LMDataParams__t =
[
    [ "bVersion", "d8/d29/structphlnLlcp__LMDataParams__t.html#a2efc2d0d4a7f4d66d4fdfc553b1c9715", null ],
    [ "bLto", "d8/d29/structphlnLlcp__LMDataParams__t.html#a2090280ca64fc881d31b990cf78c1bb0", null ],
    [ "bOpt", "d8/d29/structphlnLlcp__LMDataParams__t.html#ae9fa130ad058fc548adb20823767ddf4", null ],
    [ "wMiu", "d8/d29/structphlnLlcp__LMDataParams__t.html#a1e59b79e2052d1adaa1b06f8e8d3fc35", null ],
    [ "wWks", "d8/d29/structphlnLlcp__LMDataParams__t.html#a19fa92db5299600e119c23e3e8db4226", null ],
    [ "bAvailableTlv", "d8/d29/structphlnLlcp__LMDataParams__t.html#a0ae3af0e11468529ac6c27755e7823f1", null ]
];