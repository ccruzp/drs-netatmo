var group__phalMfNtag42xDna__SecureMessaging =
[
    [ "PHAL_MFNTAG42XDNA_NOT_AUTHENTICATED", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#gaa183810a9c7909d9c86078be35b53bf4", null ],
    [ "PHAL_MFNTAG42XDNA_AUTHENTICATE", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#ga571f7f683171c4d75cb30acc00dfa7b0", null ],
    [ "PHAL_MFNTAG42XDNA_AUTHENTICATEISO", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#ga46002f2eb4436c3791b24eebebe92d20", null ],
    [ "PHAL_MFNTAG42XDNA_AUTHENTICATEAES", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#ga3337bce165932b5779f24d53fd93d474", null ],
    [ "PHAL_MFNTAG42XDNA_AUTHENTICATEEV2", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#ga7c61258885744bc3a43c3b83b63e4080", null ],
    [ "PHAL_MFNTAG42XDNA_AUTH_TYPE_EV2", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#ga456cd245cb64b4f70ce3482509b4282b", null ],
    [ "PHAL_MFNTAG42XDNA_AUTH_TYPE_LRP", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#ga668bbbf131ca83e82b429b6f71803e67", null ],
    [ "PHAL_MFNTAG42XDNA_AUTH_TYPE_UNKNOWN", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#ga9a255e0ff66ab0ce5c886cdd29ad76a5", null ],
    [ "PHAL_MFNTAG42XDNA_CMD_AUTHENTICATE_PART2", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#gad5a4cdba2bbdf1145cd60decdf7ce11a", null ],
    [ "PHAL_MFNTAG42XDNA_AUTHNONFIRST_NON_LRP", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#ga9e92a4e0948f64e7a01827134e097fb3", null ],
    [ "PHAL_MFNTAG42XDNA_AUTHFIRST_NON_LRP", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#gad3a88630dea1f4cadef8c4d686d642ae", null ],
    [ "PHAL_MFNTAG42XDNA_AUTHNONFIRST_LRP", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#gaf1c269d9419960dd840ff1651494eb9d", null ],
    [ "PHAL_MFNTAG42XDNA_AUTHFIRST_LRP", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#ga6674a3c2cfed002f9c82a9d7111e240c", null ],
    [ "PHAL_MFNTAG42XDNA_NO_DIVERSIFICATION", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#ga8dca02eb05df8e97d3cfc603a50a5462", null ],
    [ "PHAL_MFNTAG42XDNA_DIV_METHOD_ENCR", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#ga7b96fdc50c55031124f6a4a573299fec", null ],
    [ "PHAL_MFNTAG42XDNA_DIV_METHOD_CMAC", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#ga1a6eb2773315974c53f7536df2fc9d0f", null ],
    [ "phalMfNtag42XDna_AuthenticateEv2", "d8/d7c/group__phalMfNtag42xDna__SecureMessaging.html#ga15332984ad5f6f26661bd3e88c762656", null ]
];