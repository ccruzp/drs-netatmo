var structphalMfc__Sw__DataParams__t =
[
    [ "wId", "d4/d5a/structphalMfc__Sw__DataParams__t.html#a546853dde6351d5f2f51e80d074ac5ec", null ],
    [ "pPalMifareDataParams", "d4/d5a/structphalMfc__Sw__DataParams__t.html#ab2d1fbd8230f47566b98b68a33459042", null ],
    [ "pKeyStoreDataParams", "d4/d5a/structphalMfc__Sw__DataParams__t.html#a08856cc119a212c99cebe7adad5c664c", null ]
];