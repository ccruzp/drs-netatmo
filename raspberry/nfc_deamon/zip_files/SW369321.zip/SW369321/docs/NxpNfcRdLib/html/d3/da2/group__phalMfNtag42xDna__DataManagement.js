var group__phalMfNtag42xDna__DataManagement =
[
    [ "phalMfNtag42XDna_ReadData", "d3/da2/group__phalMfNtag42xDna__DataManagement.html#ga9e0551b48e70c85d60e6d13050ca31b2", null ],
    [ "phalMfNtag42XDna_WriteData", "d3/da2/group__phalMfNtag42xDna__DataManagement.html#ga4f491284dd7e5d6dfcbdf968d4f19a03", null ]
];