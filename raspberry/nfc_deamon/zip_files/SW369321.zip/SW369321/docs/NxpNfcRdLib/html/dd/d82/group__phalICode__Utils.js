var group__phalICode__Utils =
[
    [ "phalICode_GetConfig", "dd/d82/group__phalICode__Utils.html#ga3fdabd4c73b240c7bfa44da80b664c41", null ],
    [ "phalICode_SetConfig", "dd/d82/group__phalICode__Utils.html#ga6e154949dcfff5997437afe6500808e0", null ],
    [ "phalICode_GetTagType", "dd/d82/group__phalICode__Utils.html#ga0c50f7eec1e47f7ac87b194e90e01e7f", null ]
];