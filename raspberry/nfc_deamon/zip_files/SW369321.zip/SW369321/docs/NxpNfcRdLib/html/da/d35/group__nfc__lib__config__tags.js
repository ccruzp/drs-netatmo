var group__nfc__lib__config__tags =
[
    [ "PH_NFCLIB_CONFIG_ACTIVATION_BLOCKING", "da/d35/group__nfc__lib__config__tags.html#gafcc5a66ec6e1fe309200765380959db5", null ],
    [ "PH_NFCLIB_CONFIG_ACTIVATION_TARGET_PAUSE_TIME", "da/d35/group__nfc__lib__config__tags.html#gad3d2a792324f53dca0c28a3808d23c3e", null ],
    [ "PH_NFCLIB_CONFIG_ACTIVATION_PROFILE", "da/d35/group__nfc__lib__config__tags.html#ga17211163355ed9835b42152203475414", null ],
    [ "PH_NFCLIB_CONFIG_ACTIVATION_MERGED_SAK_PRIO", "da/d35/group__nfc__lib__config__tags.html#gaa1c16e57bfc95d64b10159e415d36327", null ]
];