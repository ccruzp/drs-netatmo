var group__phpalI14443p3b__Sw =
[
    [ "phpalI14443p3b_Sw_DataParams_t", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html", [
      [ "wId", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#aadc2f825091819ccef213f7fef8844f0", null ],
      [ "pHalDataParams", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#a905f07d785d89949c4815078ef0b86a3", null ],
      [ "bExtAtqb", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#ad70bf2fea7f797cc7df3b51a715731d0", null ],
      [ "pPupi", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#acf7f1a5a4695a8aad31f357059462335", null ],
      [ "bPupiValid", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#ac4c465ea5b54466d3ccd9cace08b11e6", null ],
      [ "bCidSupported", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#aae14db7f8156a203d0d87615ecc170c1", null ],
      [ "bNadSupported", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#a996f9f19b73809031d7c418d8e06628e", null ],
      [ "bCid", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#af036b9ace2db9aa45ce38e7b1baba000", null ],
      [ "bFwi", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#a1a471466d863fae78441153dd7e857f0", null ],
      [ "bFsci", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#a512845e01218aaaaeab739d700d078ec", null ],
      [ "bFsdi", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#ace1e6c28c9620203968f1e429d198fed", null ],
      [ "bDri", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#a440fd36a17e1e8153c0d081a6b992fc8", null ],
      [ "bDsi", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#a7940ed5dbc2062c9f04417769181e8c9", null ],
      [ "bAttribParam1", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#a49dc9f941ff32bbe0fa83e8d0707cfe9", null ],
      [ "pHigherLayerInf", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#ab891ade9fb863faaafb369c1c146251f", null ],
      [ "wTxWait", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#a54d2c0be5f9992e72e511004266b2c01", null ],
      [ "wHigherLayerInfLen", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#a4ddd4d11b2a59bfb0d6957d5407b8ae8", null ],
      [ "pHigherLayerResp", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#a21c26890188dc286fe3840d83f58d2b4", null ],
      [ "wHigherLayerRespSize", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#a69c0220c26a56008606a5dadc234af4f", null ],
      [ "wHigherLayerRespLen", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#a33477c7dcde74b1e0de108b96958fe9f", null ],
      [ "bOpeMode", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#a8256f4bde4ebe3bab6e53fa6a274af0f", null ],
      [ "bPollCmd", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#aec41c2d26cc1569e207e13440332b01b", null ],
      [ "bRetryCount", "de/d10/structphpalI14443p3b__Sw__DataParams__t.html#af7b9deecce1296e52cbcc44ce5af7fcd", null ]
    ] ],
    [ "PHPAL_I14443P3B_SW_ID", "d4/df5/group__phpalI14443p3b__Sw.html#ga6a6b2a767d42fbac73b89b4df9e46bb6", null ],
    [ "phpalI14443p3b_Sw_Init", "d4/df5/group__phpalI14443p3b__Sw.html#gab3426e63166ef99b262dd549de671622", null ]
];