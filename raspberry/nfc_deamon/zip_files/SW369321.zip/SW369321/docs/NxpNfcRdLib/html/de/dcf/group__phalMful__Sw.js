var group__phalMful__Sw =
[
    [ "phalMful_Sw_DataParams_t", "d2/dda/structphalMful__Sw__DataParams__t.html", [
      [ "wId", "d2/dda/structphalMful__Sw__DataParams__t.html#a62d774d92333c57a9bbb6e0ffb168a0e", null ],
      [ "pPalMifareDataParams", "d2/dda/structphalMful__Sw__DataParams__t.html#ac8ba41e622b609239ab388cece9912b7", null ],
      [ "pKeyStoreDataParams", "d2/dda/structphalMful__Sw__DataParams__t.html#a8d6e71dab621a32ca62413ecf4759064", null ],
      [ "pCryptoDataParams", "d2/dda/structphalMful__Sw__DataParams__t.html#a663895b0e42e01506e80dcee348b8f37", null ],
      [ "pCryptoRngDataParams", "d2/dda/structphalMful__Sw__DataParams__t.html#af6c7b67d2043daf2ad053b0d25d99ee8", null ]
    ] ],
    [ "PHAL_MFUL_SW_ID", "de/dcf/group__phalMful__Sw.html#gab84d335e99813d4ba46ca85f4436d298", null ],
    [ "phalMful_Sw_Init", "de/dcf/group__phalMful__Sw.html#gae151166a85257bd024df5c6be972d716", null ]
];