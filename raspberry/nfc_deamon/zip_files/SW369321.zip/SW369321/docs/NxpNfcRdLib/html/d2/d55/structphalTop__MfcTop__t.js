var structphalTop__MfcTop__t =
[
    [ "pPalI14443paDataParams", "d2/d7b/group__phalTop__Sw.html#ga890836c013e0e2c5bcbbdb6f18bdd5b5", null ],
    [ "bCardType", "d2/d7b/group__phalTop__Sw.html#ga90d26f253a5a1d4dc31be1f3ee983fe3", null ],
    [ "bFirstNdefSector", "d2/d7b/group__phalTop__Sw.html#gaa22f3f5064c71634b8031654c4106fa1", null ],
    [ "bPreFormatted", "d2/d7b/group__phalTop__Sw.html#gad0e8829a686b5f3f90060b6c66c1c829", null ],
    [ "bNdefSectorCount", "d2/d7b/group__phalTop__Sw.html#gaf920e4399124db5fc7d30815b7a22808", null ],
    [ "bOffset", "d2/d7b/group__phalTop__Sw.html#gac5382dc8d5dcf5171cf7ac1181db4a63", null ],
    [ "bNdefMessageStart", "d2/d7b/group__phalTop__Sw.html#ga2c6ffcd05b41e1f1d75da57cc424b655", null ]
];