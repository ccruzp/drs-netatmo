var structphalTop__T2T__LockCtrlTlv__t =
[
    [ "wOffset", "d2/d7b/group__phalTop__Sw.html#gad8bc59b76a5a54f03070b33dae40d032", null ],
    [ "wByteAddr", "d2/d7b/group__phalTop__Sw.html#gae4579c81e8e24cf2d55b68b2c766fd5b", null ],
    [ "bSizeInBits", "d2/d7b/group__phalTop__Sw.html#gaa36af0441952d4fa471a848bbbf47e77", null ],
    [ "bBytesPerPage", "d2/d7b/group__phalTop__Sw.html#ga795e9766456edf504e6f7999977ead85", null ],
    [ "bBytesLockedPerBit", "d2/d7b/group__phalTop__Sw.html#gaf077c6cc686b7cc7a91190e98bc0d8c7", null ]
];