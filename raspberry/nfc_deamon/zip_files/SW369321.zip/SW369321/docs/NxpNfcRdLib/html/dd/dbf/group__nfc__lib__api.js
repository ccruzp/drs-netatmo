var group__nfc__lib__api =
[
    [ "phNfcLib_SetContext", "dd/dbf/group__nfc__lib__api.html#ga7640a5721f60bf5888ba2dc5a5399489", null ],
    [ "phNfcLib_Init", "dd/dbf/group__nfc__lib__api.html#gae122aff010dbef6af9b39776e892185e", null ],
    [ "phNfcLib_DeInit", "dd/dbf/group__nfc__lib__api.html#ga1fee0b25277edc628d49871ea1d10280", null ],
    [ "phNfcLib_Activate", "dd/dbf/group__nfc__lib__api.html#ga0cf7edfcea7dd52997c58544b15795c2", null ],
    [ "phNfcLib_Transmit", "dd/dbf/group__nfc__lib__api.html#ga966df0e8a7989d581dfd7ee65e5d5b91", null ],
    [ "phNfcLib_Receive", "dd/dbf/group__nfc__lib__api.html#ga5d2fd66f63c9729ef1f744fa12c6f4b2", null ],
    [ "phNfcLib_SetConfig", "dd/dbf/group__nfc__lib__api.html#gad86911ed06a7d47986dc6c6ab76b9b24", null ],
    [ "phNfcLib_SetConfig_Value", "dd/dbf/group__nfc__lib__api.html#ga9721a3e495c55af73957923f1bd9fcb9", null ],
    [ "phNfcLib_GetConfig", "dd/dbf/group__nfc__lib__api.html#ga1b3cb257a719ff6fa623e2bf98b213f4", null ],
    [ "phNfcLib_Deactivate", "dd/dbf/group__nfc__lib__api.html#ga00dbecbfcc859ee6b1bfbd5f6d05fbcc", null ],
    [ "phNfcLib_AsyncAbort", "dd/dbf/group__nfc__lib__api.html#ga9def0b9cd07364b32485048e2f8072eb", null ],
    [ "phNfcLib_GetDataParams", "dd/dbf/group__nfc__lib__api.html#gaa87f92a83d757bccadf376563242729d", null ]
];