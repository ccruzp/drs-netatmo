var group__ph__Typedefs =
[
    [ "uint8_t", "d7/d83/group__ph__Typedefs.html#gaba7bc1797add20fe3efdf37ced1182c5", null ],
    [ "uint16_t", "d7/d83/group__ph__Typedefs.html#ga273cf69d639a59973b6019625df33e30", null ],
    [ "uint32_t", "d7/d83/group__ph__Typedefs.html#ga435d1572bf3f880d55459d9805097f62", null ],
    [ "int8_t", "d7/d83/group__ph__Typedefs.html#gaef44329758059c91c76d334e8fc09700", null ],
    [ "int16_t", "d7/d83/group__ph__Typedefs.html#gaa343fa3b3d06292b959ffdd4c4703b06", null ],
    [ "int32_t", "d7/d83/group__ph__Typedefs.html#ga32f2e37ee053cf2ce8ca28d1f74630e5", null ],
    [ "float32_t", "d7/d83/group__ph__Typedefs.html#ga4611b605e45ab401f02cab15c5e38715", null ],
    [ "ph_NfcHandle", "d7/d83/group__ph__Typedefs.html#ga9f78ae94574043d48750d81550a554d6", null ]
];