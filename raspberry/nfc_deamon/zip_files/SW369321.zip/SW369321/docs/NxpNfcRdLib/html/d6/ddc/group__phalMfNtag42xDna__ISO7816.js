var group__phalMfNtag42xDna__ISO7816 =
[
    [ "PHAL_MFNTAG42XDNA_FCI_RETURNED", "d6/ddc/group__phalMfNtag42xDna__ISO7816.html#ga54cdeb251ef3dfc267eee3b935e66b19", null ],
    [ "PHAL_MFNTAG42XDNA_FCI_NOT_RETURNED", "d6/ddc/group__phalMfNtag42xDna__ISO7816.html#ga7539d96008e4d148328c5b71bcb68efa", null ],
    [ "PHAL_MFNTAG42XDNA_SELECTOR_0", "d6/ddc/group__phalMfNtag42xDna__ISO7816.html#ga8409873e89c25ae7ce3ec095d6b7d023", null ],
    [ "PHAL_MFNTAG42XDNA_SELECTOR_1", "d6/ddc/group__phalMfNtag42xDna__ISO7816.html#ga9576ab8fac951866ca479d9ce0088964", null ],
    [ "PHAL_MFNTAG42XDNA_SELECTOR_2", "d6/ddc/group__phalMfNtag42xDna__ISO7816.html#gae6a52adea472f2137348194f6cd2c7f3", null ],
    [ "PHAL_MFNTAG42XDNA_SELECTOR_3", "d6/ddc/group__phalMfNtag42xDna__ISO7816.html#ga84a384f634fe552f47573d3e56db5791", null ],
    [ "PHAL_MFNTAG42XDNA_SELECTOR_4", "d6/ddc/group__phalMfNtag42xDna__ISO7816.html#gad935838c9827353c236fb4afe33ddd2f", null ],
    [ "phalMfNtag42XDna_IsoSelectFile", "d6/ddc/group__phalMfNtag42xDna__ISO7816.html#gaa745c0a0930274207a40493f82ea9418", null ],
    [ "phalMfNtag42XDna_IsoReadBinary", "d6/ddc/group__phalMfNtag42xDna__ISO7816.html#gae76bef6c4b63137e9176e547c03d53d5", null ],
    [ "phalMfNtag42XDna_IsoUpdateBinary", "d6/ddc/group__phalMfNtag42xDna__ISO7816.html#gac7a988ed1cab9debd4fb9cb29cbe4f72", null ]
];