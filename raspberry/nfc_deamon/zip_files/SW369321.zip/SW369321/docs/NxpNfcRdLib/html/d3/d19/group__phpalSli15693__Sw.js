var group__phpalSli15693__Sw =
[
    [ "phpalSli15693_Sw_DataParams_t", "da/d82/structphpalSli15693__Sw__DataParams__t.html", [
      [ "wId", "da/d82/structphpalSli15693__Sw__DataParams__t.html#ae2abb33bd934ee8d60f233a946936b1d", null ],
      [ "pHalDataParams", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a45a59b1a3600142d2e52364d851ed219", null ],
      [ "wAdditionalInfo", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a68d5be297e15d3b63363ef663b3c981f", null ],
      [ "bFlags", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a071173cd32413a31d1474946d8299c5a", null ],
      [ "pUid", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a6e9004cabe3f3319c16815c654e21755", null ],
      [ "bUidBitLength", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a5fad8a6d11229557a82e2f0cc121549e", null ],
      [ "bExplicitlyAddressed", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a5b62cf5fd8eb47f71e9f033c19fd134f", null ],
      [ "bOpeMode", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a16b7fad74d9529a374088222863a3961", null ],
      [ "bBuffering", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a8d5a6a1b279cbd99e01fef0b6fd829e8", null ]
    ] ],
    [ "PHPAL_SLI15693_SW_ID", "d3/d19/group__phpalSli15693__Sw.html#ga831e69b50c98f7f08bf997ad275dc47c", null ],
    [ "phpalSli15693_Sw_Init", "d3/d19/group__phpalSli15693__Sw.html#ga63b28665b9b33d4004ee760b837f6022", null ]
];