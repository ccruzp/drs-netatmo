var group__phpalI18000p3m3__Sw =
[
    [ "phpalI18000p3m3_Sw_DataParams_t", "d2/dad/structphpalI18000p3m3__Sw__DataParams__t.html", [
      [ "wId", "d2/dad/structphpalI18000p3m3__Sw__DataParams__t.html#aab9a6514acebfbadca27aa42be6e8545", null ],
      [ "pHalDataParams", "d2/dad/structphpalI18000p3m3__Sw__DataParams__t.html#a4e2516dfe49da0216f4c49ddf6eccd6b", null ],
      [ "bSession", "d2/dad/structphpalI18000p3m3__Sw__DataParams__t.html#ab23490bc70e7e376a0efcf481c106eb2", null ],
      [ "abStoredCRC", "d2/dad/structphpalI18000p3m3__Sw__DataParams__t.html#afe4d6e4c28e2583e54dc03bff527733f", null ],
      [ "bStoredCRCValid", "d2/dad/structphpalI18000p3m3__Sw__DataParams__t.html#a51ffdaf5e5fa126aae2163feaee640ec", null ]
    ] ],
    [ "PHPAL_I18000P3M3_SW_ID", "d2/d95/group__phpalI18000p3m3__Sw.html#gaccecfc8cd2443a9706efb62ab8d34cda", null ],
    [ "phpalI18000p3m3_Sw_Init", "d2/d95/group__phpalI18000p3m3__Sw.html#ga823d78455054d0874843db79cb3ab08d", null ]
];