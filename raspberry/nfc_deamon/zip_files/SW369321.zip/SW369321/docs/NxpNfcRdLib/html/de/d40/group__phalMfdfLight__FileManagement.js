var group__phalMfdfLight__FileManagement =
[
    [ "PHAL_MFDFLIGHT_CRTMACFILE_DIVERSIFICATION_OFF", "de/d40/group__phalMfdfLight__FileManagement.html#ga7832616bc9e05514ab2fb8e181a052eb", null ],
    [ "PHAL_MFDFLIGHT_CRTMACFILE_DIVERSIFICATION_ON", "de/d40/group__phalMfdfLight__FileManagement.html#gabd86d68ca3df2a0d791cd324888b66e5", null ],
    [ "PHAL_MFDFLIGHT_FILE_OPTION_PLAIN", "de/d40/group__phalMfdfLight__FileManagement.html#gae93e3167e9667a4d69d14109f7f8df29", null ],
    [ "PHAL_MFDFLIGHT_FILE_OPTION_PLAIN_1", "de/d40/group__phalMfdfLight__FileManagement.html#ga0a1e4b7f84e1e4255ebb3b047e726cd5", null ],
    [ "PHAL_MFDFLIGHT_FILE_OPTION_MACD", "de/d40/group__phalMfdfLight__FileManagement.html#gafbe774b69e877b8d55e35131c6116cb4", null ],
    [ "PHAL_MFDFLIGHT_FILE_OPTION_ENC", "de/d40/group__phalMfdfLight__FileManagement.html#ga3510f71ccb7bcb6f57b7c23a6c30efbc", null ],
    [ "PHAL_MFDFLIGHT_MFM_SPECIFICS_ENABLED", "de/d40/group__phalMfdfLight__FileManagement.html#gac2c860af76d460ddfc935b366938fd96", null ],
    [ "PHAL_MFDFLIGHT_TMCLIMITCONFIG", "de/d40/group__phalMfdfLight__FileManagement.html#gaaeae9f8e43e30db080474f95a6b96c86", null ],
    [ "PHAL_MFDFLIGHT_EXCLUNAUTHCONFIG", "de/d40/group__phalMfdfLight__FileManagement.html#gaf62054a8f06e77719e7955adb33fc991", null ],
    [ "phalMfdfLight_CreateTransactionMacFile", "de/d40/group__phalMfdfLight__FileManagement.html#ga1945282e23ea5de6b1bd56494841cc50", null ],
    [ "phalMfdfLight_DeleteFile", "de/d40/group__phalMfdfLight__FileManagement.html#ga5dec2dad5ee62d3e8a7f8ec06f6b6041", null ],
    [ "phalMfdfLight_GetFileIDs", "de/d40/group__phalMfdfLight__FileManagement.html#ga9b3a9e9dcbf608f1231a3f716421351f", null ],
    [ "phalMfdfLight_GetISOFileIDs", "de/d40/group__phalMfdfLight__FileManagement.html#gaa42cf48ca0d625b5c7c63ee3e349b3f6", null ],
    [ "phalMfdfLight_GetFileSettings", "de/d40/group__phalMfdfLight__FileManagement.html#gae70c8ef30042c5581d46c8cec980dbb9", null ],
    [ "phalMfdfLight_ChangeFileSettings", "de/d40/group__phalMfdfLight__FileManagement.html#gac3434bc2b0abc85956b6bf40af0ba444", null ]
];