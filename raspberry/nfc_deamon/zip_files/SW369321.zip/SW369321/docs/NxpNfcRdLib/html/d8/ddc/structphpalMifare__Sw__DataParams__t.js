var structphpalMifare__Sw__DataParams__t =
[
    [ "wId", "d8/ddc/structphpalMifare__Sw__DataParams__t.html#ab139b8bcdaab98106a9e2efa9178b8f6", null ],
    [ "pHalDataParams", "d8/ddc/structphpalMifare__Sw__DataParams__t.html#ac4121790ce16928ea09bcc26d25d03e3", null ],
    [ "pPalI14443p4DataParams", "d8/ddc/structphpalMifare__Sw__DataParams__t.html#a5e93771a7d68e819b609e8e6eaf75166", null ]
];