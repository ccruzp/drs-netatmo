var structphalTop__T1T__ProprietaryTlv__t =
[
    [ "wOffset", "d2/d7b/group__phalTop__Sw.html#gafdc6eb02e29d289dc9a3d89efcb583a1", null ],
    [ "wLength", "d2/d7b/group__phalTop__Sw.html#gad0f484532ee112433fde41dfb57ebb5e", null ]
];